package com.example.mockHW3Cats.APIClasses;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

// new since Glide v4
@GlideModule
public class AppGlide extends AppGlideModule{
    // leave empty for now
}

