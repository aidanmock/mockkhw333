package com.example.mockHW3Cats;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mockHW3Cats.APIClasses.Cat;

import java.util.ArrayList;

public class SearchAdapter extends RecyclerView.Adapter<CatViewHolder> implements Filterable {
    Context context;


    ArrayList<Cat> listOfCats;
    ArrayList<Cat> mFilterList;

    public SearchAdapter(ArrayList<Cat> catsList) {
        this.listOfCats = catsList;
        this.mFilterList = new ArrayList<>();
    }
    @Override
    public CatViewHolder onCreateViewHolder (@NonNull ViewGroup parent, int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cat, parent, false);
        this.context = parent.getContext();
        CatViewHolder catViewHolder = new CatViewHolder(view);
        return catViewHolder;
    }
    @Override
    public void onBindViewHolder(@NonNull CatViewHolder holder, final int position){
        if (mFilterList.isEmpty()){
            mFilterList = listOfCats;
        }
        final Cat catAtPosition = mFilterList.get(position);
        System.out.println("Filtered Cat List: "  +catAtPosition.getName()+" "+ catAtPosition.getId());
        holder.catName.setText(catAtPosition.getName());
        holder.linearCats.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), DetailActivity.class);
                System.out.println(catAtPosition.getId());
                intent.putExtra("catID",catAtPosition.getId());
                v.getContext().startActivity(intent);
            }
        }); }
    @Override
    public int getItemCount(){
        if (mFilterList.isEmpty()){
            return listOfCats.size();
        } else {
            return mFilterList.size();
        } }
    public void setData(ArrayList<Cat> cats) {
        this.listOfCats = cats;
    }


    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String searchString = charSequence.toString();
                if (searchString.isEmpty()) {
                    mFilterList = listOfCats;
                }

                else {
                    ArrayList<Cat> filteredList = new ArrayList<>();
                    for (Cat cat : listOfCats) {
                        if (cat.getName().toLowerCase().contains(searchString)) {
                            filteredList.add(cat);
                        } }
                    mFilterList = filteredList;
                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = mFilterList;
                return filterResults;
            }
            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                mFilterList = (ArrayList<Cat>) filterResults.values;
                notifyDataSetChanged();
  }
        };
    }
}
