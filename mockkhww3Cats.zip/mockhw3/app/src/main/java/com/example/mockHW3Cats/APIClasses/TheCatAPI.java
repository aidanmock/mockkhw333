package com.example.mockHW3Cats.APIClasses;

import java.util.ArrayList;

public class TheCatAPI {
    ArrayList<Cat> breeds;
    String url;

    public ArrayList<Cat> getBreeds() {
        return breeds;
    }

    public String getUrl() {
        return url;
    }

}
